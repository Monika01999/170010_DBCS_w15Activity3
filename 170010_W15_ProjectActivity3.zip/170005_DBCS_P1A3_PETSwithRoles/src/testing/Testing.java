package testing;


import static org.junit.Assert.assertEquals;

import org.junit.Test;


import junit.*;

public class Testing {

    @Test
    public void test1() {
        Caller tester = new Caller();
        assertEquals("Name is already present in DataBase!", tester.insertDBlifecycle("Varsha@123","monika"), "Name is already present in DataBase!");
    }
    @Test
    public void test2() {
        Caller tester = new Caller();
        assertEquals("Database Updated", tester.insertDBlifecycle("varsha","monika"), "DataBase Updated");
    }
}

