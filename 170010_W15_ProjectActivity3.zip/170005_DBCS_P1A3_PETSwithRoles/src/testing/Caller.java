package testing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Caller {

	
	public String insertDBlifecycle(String f1, String f2){
	    
	     
	        	try {
	             Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/DBCSW15","root","Varsha@123");
	             String sql = "INSERT INTO lifecycles(lifecycle_name, lifecycle_description)" +
	            	        "VALUES (?, ?)";
	             PreparedStatement preparedStatement = connection.prepareStatement(sql);
	             preparedStatement.setString(1, f1);
	             preparedStatement.setString(2, f2);
	             preparedStatement.executeUpdate();
	             String sql2 = "delete from lifecycles where lifecycle_name= ?";
	            		 PreparedStatement preparedStatement2 = connection.prepareStatement(sql2);
	            		 preparedStatement2.setString(1, f1);
	            		 preparedStatement2.executeUpdate();
	            return "DataBase Updated";
	        	}
	        	catch(Exception e) {
	        		
	        		 return"Name already exists in DataBase!";
	        	
	        	}
	
	     }
}
